/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina.ant.jmx;

/**
 * Represents a single argument for JMX operations.
 */
public class Arg {

    /**
     * Constructs a new Arg.
     */
    public Arg() {
    }

    private String type;
    private String value;

    /**
     * Sets the argument type.
     *
     * @param type the argument type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Sets the argument value.
     *
     * @param value the argument value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Returns the argument value.
     *
     * @return the argument value
     */
    public String getValue() {
        return value;
    }

    /**
     * Returns the argument type.
     *
     * @return the argument type
     */
    public String getType() {
        return type;
    }
}
