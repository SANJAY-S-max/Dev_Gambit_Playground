/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina.ant.jmx;


import java.util.ArrayList;
import java.util.List;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import org.apache.tools.ant.BuildException;


/**
 * Access <em>JMX</em> JSR 160 MBeans Server.
 * <ul>
 * <li>open more than one JSR 160 rmi connection</li>
 * <li>Get/Set Mbeans attributes</li>
 * <li>Call Mbean Operation with arguments</li>
 * <li>Argument values can be converted from string to int,long,float,double,boolean,ObjectName or InetAddress</li>
 * <li>Query Mbeans</li>
 * <li>Show Get, Call, Query result at Ant console log</li>
 * <li>Bind Get, Call, Query result at Ant properties</li>
 * </ul>
 * Examples:
 * <ul>
 * <li>Get a session attribute hello from session with ref <em>${sessionid.0}</em> form app
 * <em>Catalina:type=Manager,context=/ClusterTest,host=localhost</em>
 *
 * <pre>
 *   &lt;jmx:invoke
 *           name="Catalina:type=Manager,context=/ClusterTest,host=localhost"
 *           operation="getSessionAttribute"
 *           resultproperty="hello"&gt;
 *         &lt;arg value="${sessionid.0}"/&gt;
 *         &lt;arg value="Hello"/&gt;
 *   &lt;/jmx:invoke&gt;
 * </pre>
 *
 * </li>
 * <li>Create new AccessLogger at localhost
 *
 * <pre>
 *   &lt;jmx:invoke
 *           name="Catalina:type=MBeanFactory"
 *           operation="createAccessLoggerValve"
 *           resultproperty="accessLoggerObjectName"&gt;
 *         &lt;arg value="Catalina:type=Host,host=localhost"/&gt;
 *   &lt;/jmx:invoke&gt;
 * </pre>
 *
 * </li>
 * <li>Remove existing AccessLogger at localhost
 *
 * <pre>
 *   &lt;jmx:invoke
 *           name="Catalina:type=MBeanFactory"
 *           operation="removeValve"&gt;
 *         &lt;arg value="Catalina:type=Valve,name=AccessLogValve,host=localhost"/&gt;
 *   &lt;/jmx:invoke&gt;
 * </pre>
 *
 * </li>
 * </ul>
 * <p>
 * First call to a remote MBeanserver save the JMXConnection a referenz <em>jmx.server</em>
 * </p>
 * These tasks require Ant 1.6 or later interface.
 *
 * @since 5.5.10
 */
public class JMXAccessorInvokeTask extends JMXAccessorTask {

    /**
     * Constructs a new JMXAccessorInvokeTask.
     */
    public JMXAccessorInvokeTask() {
    }


    // ----------------------------------------------------- Instance Variables

    private String operation;
    private List<Arg> args = new ArrayList<>();

    // ------------------------------------------------------------- Properties

    /**
     * Get the MBean operation name.
     *
     * @return the operation name
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Set the MBean operation name.
     *
     * @param operation the operation to set
     */
    public void setOperation(String operation) {
        this.operation = operation;
    }

    /**
     * Add an argument for the MBean operation.
     *
     * @param arg the argument to add
     */
    public void addArg(Arg arg) {
        args.add(arg);
    }

    /**
     * Get the arguments for the MBean operation.
     *
     * @return the arguments
     */
    public List<Arg> getArgs() {
        return args;
    }

    /**
     * Set the arguments for the MBean operation.
     *
     * @param args the arguments to set
     */
    public void setArgs(List<Arg> args) {
        this.args = args;
    }

    // ------------------------------------------------------ protected Methods

    @Override
    public String jmxExecute(MBeanServerConnection jmxServerConnection) throws Exception {

        if (getName() == null) {
            throw new BuildException("Must specify a 'name'");
        }
        if ((operation == null)) {
            throw new BuildException("Must specify a 'operation' for call");
        }
        if (jmxServerConnection == null) {
            throw new BuildException("Must open a connection!");
        }
        return jmxInvoke(jmxServerConnection, getName());
    }

    /**
     * Invoke specified operation.
     *
     * @param jmxServerConnection Connection to the JMX server
     * @param name                The MBean name
     *
     * @return null (no error message to report other than exception)
     *
     * @throws Exception An error occurred
     */
    protected String jmxInvoke(MBeanServerConnection jmxServerConnection, String name) throws Exception {
        Object result;
        if (args == null) {
            result = jmxServerConnection.invoke(new ObjectName(name), operation, null, null);
        } else {
            Object[] argsA = new Object[args.size()];
            String[] sigA = new String[args.size()];
            for (int i = 0; i < args.size(); i++) {
                Arg arg = args.get(i);
                if (arg.getType() == null) {
                    arg.setType("java.lang.String");
                    sigA[i] = arg.getType();
                    argsA[i] = arg.getValue();
                } else {
                    sigA[i] = arg.getType();
                    argsA[i] = convertStringToType(arg.getValue(), arg.getType());
                }
            }
            result = jmxServerConnection.invoke(new ObjectName(name), operation, argsA, sigA);
        }
        if (result != null) {
            echoResult(operation, result);
            createProperty(result);
        }
        return null;
    }

}
