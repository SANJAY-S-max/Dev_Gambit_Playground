/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina.authenticator;

import java.io.Serializable;

import org.apache.catalina.Context;
import org.apache.catalina.Session;

/**
 * Key used by SSO to identify a session. This key is used rather than the actual session to facilitate the replication
 * of the SSO information across a cluster where replicating the entire session would generate significant, unnecessary
 * overhead.
 */
public class SingleSignOnSessionKey implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * The session ID.
     */
    private final String sessionId;
    /**
     * The context name.
     */
    private final String contextName;
    /**
     * The host name.
     */
    private final String hostName;

    /**
     * Creates a session key from the given session, using the session's current ID.
     *
     * @param session the session from which to extract the key information
     */
    public SingleSignOnSessionKey(Session session) {
        this.sessionId = session.getId();
        Context context = session.getManager().getContext();
        this.contextName = context.getName();
        this.hostName = context.getParent().getName();
    }

    /**
     * Creates a session key using the given session context and an explicit session ID.
     *
     * @param session the session from which to extract context and host information
     * @param sessionId the session ID to use for this key
     */
    public SingleSignOnSessionKey(Session session, String sessionId) {
        this.sessionId = sessionId;
        Context context = session.getManager().getContext();
        this.contextName = context.getName();
        this.hostName = context.getParent().getName();
    }

    /**
     * Returns the session ID associated with this key.
     *
     * @return the session ID
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * Returns the context name associated with this key.
     *
     * @return the context name
     */
    public String getContextName() {
        return contextName;
    }

    /**
     * Returns the host name associated with this key.
     *
     * @return the host name
     */
    public String getHostName() {
        return hostName;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((sessionId == null) ? 0 : sessionId.hashCode());
        result = prime * result + ((contextName == null) ? 0 : contextName.hashCode());
        result = prime * result + ((hostName == null) ? 0 : hostName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SingleSignOnSessionKey other = (SingleSignOnSessionKey) obj;
        if (sessionId == null) {
            if (other.sessionId != null) {
                return false;
            }
        } else if (!sessionId.equals(other.sessionId)) {
            return false;
        }
        if (contextName == null) {
            if (other.contextName != null) {
                return false;
            }
        } else if (!contextName.equals(other.contextName)) {
            return false;
        }
        if (hostName == null) {
            return other.hostName == null;
        } else {
            return hostName.equals(other.hostName);
        }
    }

    @Override
    public String toString() {
        // Session ID is 32. Standard text is 36. Host could easily be 20+.
        // Context could be anything from 0 upwards. 128 seems like a reasonable
        // size to accommodate most cases without being too big.
        return "Host: [" + hostName + "], Context: [" + contextName + "], SessionID: [" + sessionId + ']';
    }
}
