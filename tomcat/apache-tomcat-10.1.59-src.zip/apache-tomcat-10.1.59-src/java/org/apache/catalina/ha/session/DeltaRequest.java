/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina.ha.session;

import java.io.ByteArrayOutputStream;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.Principal;
import java.util.ArrayDeque;
import java.util.Deque;

import org.apache.catalina.SessionListener;
import org.apache.catalina.realm.GenericPrincipal;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.res.StringManager;

/**
 * This class is used to track the series of actions that happens when a request is executed. These actions will then
 * translate into invocations of methods on the actual session.
 * <p>
 * This class is NOT thread safe. One DeltaRequest per session.
 */
public class DeltaRequest implements Externalizable {

    /**
     * The logger for this class.
     */
    public static final Log log = LogFactory.getLog(DeltaRequest.class);

    /**
     * The string manager for this package.
     */
    protected static final StringManager sm = StringManager.getManager(DeltaRequest.class);

    /**
     * Action type for session attributes.
     */
    public static final int TYPE_ATTRIBUTE = 0;

    /**
     * Action type for session principal.
     */
    public static final int TYPE_PRINCIPAL = 1;

    /**
     * Action type for session new flag.
     */
    public static final int TYPE_ISNEW = 2;

    /**
     * Action type for session max inactive interval.
     */
    public static final int TYPE_MAXINTERVAL = 3;

    /**
     * Action type for session authentication type.
     */
    public static final int TYPE_AUTHTYPE = 4;

    /**
     * Action type for session listener.
     */
    public static final int TYPE_LISTENER = 5;

    /**
     * Action type for session note.
     */
    public static final int TYPE_NOTE = 6;

    /**
     * Action to set a value.
     */
    public static final int ACTION_SET = 0;

    /**
     * Action to remove a value.
     */
    public static final int ACTION_REMOVE = 1;

    /**
     * Name used for principal actions.
     */
    public static final String NAME_PRINCIPAL = "__SET__PRINCIPAL__";

    /**
     * Name used for max inactive interval actions.
     */
    public static final String NAME_MAXINTERVAL = "__SET__MAXINTERVAL__";

    /**
     * Name used for new flag actions.
     */
    public static final String NAME_ISNEW = "__SET__ISNEW__";

    /**
     * Name used for auth type actions.
     */
    public static final String NAME_AUTHTYPE = "__SET__AUTHTYPE__";

    /**
     * Name used for listener actions.
     */
    public static final String NAME_LISTENER = "__SET__LISTENER__";

    private String sessionId;
    private final Deque<AttributeInfo> actions = new ArrayDeque<>();
    private final Deque<AttributeInfo> actionPool = new ArrayDeque<>();

    private boolean recordAllActions = false;

    /**
     * Default constructor required by {@link java.io.Externalizable}.
     */
    public DeltaRequest() {

    }

    /**
     * Construct a new DeltaRequest.
     *
     * @param sessionId         Session identifier
     * @param recordAllActions  Record all actions, including duplicates
     */
    public DeltaRequest(String sessionId, boolean recordAllActions) {
        this.recordAllActions = recordAllActions;
        if (sessionId != null) {
            setSessionId(sessionId);
        }
    }


    /**
     * Record a set attribute action.
     *
     * @param name  Attribute name
     * @param value Attribute value
     */
    public void setAttribute(String name, Object value) {
        int action = (value == null) ? ACTION_REMOVE : ACTION_SET;
        addAction(TYPE_ATTRIBUTE, action, name, value);
    }

    /**
     * Record a remove attribute action.
     *
     * @param name Attribute name
     */
    public void removeAttribute(String name) {
        addAction(TYPE_ATTRIBUTE, ACTION_REMOVE, name, null);
    }

    /**
     * Record a set note action.
     *
     * @param name  Note name
     * @param value Note value
     */
    public void setNote(String name, Object value) {
        int action = (value == null) ? ACTION_REMOVE : ACTION_SET;
        addAction(TYPE_NOTE, action, name, value);
    }

    /**
     * Record a remove note action.
     *
     * @param name Note name
     */
    public void removeNote(String name) {
        addAction(TYPE_NOTE, ACTION_REMOVE, name, null);
    }

    /**
     * Record a set max inactive interval action.
     *
     * @param interval Max inactive interval in seconds
     */
    public void setMaxInactiveInterval(int interval) {
        addAction(TYPE_MAXINTERVAL, ACTION_SET, NAME_MAXINTERVAL, Integer.valueOf(interval));
    }

    /**
     * Only support principals from type {@link GenericPrincipal GenericPrincipal}
     *
     * @param p Session principal
     *
     * @see GenericPrincipal
     */
    public void setPrincipal(Principal p) {
        int action = (p == null) ? ACTION_REMOVE : ACTION_SET;
        GenericPrincipal gp = null;
        if (p != null) {
            if (p instanceof GenericPrincipal) {
                gp = (GenericPrincipal) p;
                if (log.isDebugEnabled()) {
                    log.debug(sm.getString("deltaRequest.showPrincipal", p.getName(), getSessionId()));
                }
            } else {
                log.error(sm.getString("deltaRequest.wrongPrincipalClass", p.getClass().getName()));
            }
        }
        addAction(TYPE_PRINCIPAL, action, NAME_PRINCIPAL, gp);
    }

    /**
     * Record a set new action.
     *
     * @param n New flag value
     */
    public void setNew(boolean n) {
        addAction(TYPE_ISNEW, ACTION_SET, NAME_ISNEW, Boolean.valueOf(n));
    }

    /**
     * Record a set auth type action.
     *
     * @param authType Authentication type
     */
    public void setAuthType(String authType) {
        int action = (authType == null) ? ACTION_REMOVE : ACTION_SET;
        addAction(TYPE_AUTHTYPE, action, NAME_AUTHTYPE, authType);
    }

    /**
     * Record an add session listener action.
     *
     * @param listener Session listener to add
     */
    public void addSessionListener(SessionListener listener) {
        addAction(TYPE_LISTENER, ACTION_SET, NAME_LISTENER, listener);
    }

    /**
     * Record a remove session listener action.
     *
     * @param listener Session listener to remove
     */
    public void removeSessionListener(SessionListener listener) {
        addAction(TYPE_LISTENER, ACTION_REMOVE, NAME_LISTENER, listener);
    }

    /**
     * Add an action to the list of actions to be executed.
     *
     * @param type    Action type
     * @param action  Action (set or remove)
     * @param name    Attribute or property name
     * @param value   Attribute or property value
     */
    protected void addAction(int type, int action, String name, Object value) {
        AttributeInfo info;
        if (!this.actionPool.isEmpty()) {
            try {
                info = actionPool.removeFirst();
            } catch (Exception e) {
                log.error(sm.getString("deltaRequest.removeUnable"), e);
                info = new AttributeInfo(type, action, name, value);
            }
            info.init(type, action, name, value);
        } else {
            info = new AttributeInfo(type, action, name, value);
        }
        // if we have already done something to this attribute, make sure
        // we don't send multiple actions across the wire
        if (!recordAllActions) {
            try {
                actions.remove(info);
            } catch (java.util.NoSuchElementException x) {
                // do nothing, we wanted to remove it anyway
            }
        }
        // add the action
        actions.addLast(info);
    }

    /**
     * Execute all recorded actions on the given session.
     *
     * @param session           Target session
     * @param notifyListeners   Whether to notify session listeners
     */
    public void execute(DeltaSession session, boolean notifyListeners) {
        if (!this.sessionId.equals(session.getId())) {
            throw new IllegalArgumentException(sm.getString("deltaRequest.ssid.mismatch"));
        }
        session.access();
        for (AttributeInfo info : actions) {
            switch (info.getType()) {
                case TYPE_ATTRIBUTE:
                    if (info.getAction() == ACTION_SET) {
                        if (log.isTraceEnabled()) {
                            log.trace("Session.setAttribute('" + info.getName() + "', '" + info.getValue() + "')");
                        }
                        session.setAttribute(info.getName(), info.getValue(), notifyListeners, false);
                    } else {
                        if (log.isTraceEnabled()) {
                            log.trace("Session.removeAttribute('" + info.getName() + "')");
                        }
                        session.removeAttribute(info.getName(), notifyListeners, false);
                    }

                    break;
                case TYPE_ISNEW:
                    if (log.isTraceEnabled()) {
                        log.trace("Session.setNew('" + info.getValue() + "')");
                    }
                    session.setNew(((Boolean) info.getValue()).booleanValue(), false);
                    break;
                case TYPE_MAXINTERVAL:
                    if (log.isTraceEnabled()) {
                        log.trace("Session.setMaxInactiveInterval('" + info.getValue() + "')");
                    }
                    session.setMaxInactiveInterval(((Integer) info.getValue()).intValue(), false);
                    break;
                case TYPE_PRINCIPAL:
                    Principal p = null;
                    if (info.getAction() == ACTION_SET) {
                        p = (Principal) info.getValue();
                    }
                    session.setPrincipal(p, false);
                    break;
                case TYPE_AUTHTYPE:
                    String authType = null;
                    if (info.getAction() == ACTION_SET) {
                        authType = (String) info.getValue();
                    }
                    session.setAuthType(authType, false);
                    break;
                case TYPE_LISTENER:
                    SessionListener listener = (SessionListener) info.getValue();
                    if (info.getAction() == ACTION_SET) {
                        session.addSessionListener(listener, false);
                    } else {
                        session.removeSessionListener(listener, false);
                    }
                    break;
                case TYPE_NOTE:
                    if (info.getAction() == ACTION_SET) {
                        if (log.isTraceEnabled()) {
                            log.trace("Session.setNote('" + info.getName() + "', '" + info.getValue() + "')");
                        }
                        session.setNote(info.getName(), info.getValue(), false);
                    } else {
                        if (log.isTraceEnabled()) {
                            log.trace("Session.removeNote('" + info.getName() + "')");
                        }
                        session.removeNote(info.getName(), false);
                    }

                    break;
                default:
                    log.warn(sm.getString("deltaRequest.invalidAttributeInfoType", info));
            }// switch
        } // for
        session.endAccess();
        reset();
    }

    /**
     * Reset this request, returning all action objects to the pool.
     */
    public void reset() {
        while (!actions.isEmpty()) {
            try {
                AttributeInfo info = actions.removeFirst();
                info.recycle();
                actionPool.addLast(info);
            } catch (Exception e) {
                log.error(sm.getString("deltaRequest.removeUnable"), e);
            }
        }
    }

    /**
     * Get the session identifier.
     *
     * @return Session identifier
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * Set the session identifier.
     *
     * @param sessionId Session identifier
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
        if (sessionId == null) {
            String msg = sm.getString("deltaRequest.ssid.null");
            log.error(msg, new Exception(msg));
        }
    }

    /**
     * Get the number of actions recorded.
     *
     * @return Number of actions
     */
    public int getSize() {
        return actions.size();
    }

    /**
     * Clear all actions and the action pool.
     */
    public void clear() {
        actions.clear();
        actionPool.clear();
    }

    @Override
    public void readExternal(java.io.ObjectInput in) throws IOException, ClassNotFoundException {
        // sessionId - String
        // recordAll - boolean
        // size - int
        // AttributeInfo - in an array
        reset();
        sessionId = in.readUTF();
        recordAllActions = in.readBoolean();
        int cnt = in.readInt();
        for (int i = 0; i < cnt; i++) {
            AttributeInfo info;
            if (!this.actionPool.isEmpty()) {
                try {
                    info = actionPool.removeFirst();
                } catch (Exception e) {
                    log.error(sm.getString("deltaRequest.removeUnable"), e);
                    info = new AttributeInfo();
                }
            } else {
                info = new AttributeInfo();
            }
            info.readExternal(in);
            actions.addLast(info);
        } // for
    }


    @Override
    public void writeExternal(java.io.ObjectOutput out) throws IOException {
        // sessionId - String
        // recordAll - boolean
        // size - int
        // AttributeInfo - in an array
        out.writeUTF(getSessionId());
        out.writeBoolean(recordAllActions);
        out.writeInt(getSize());
        for (AttributeInfo info : actions) {
            info.writeExternal(out);
        }
    }

    /**
     * serialize DeltaRequest
     *
     * @see DeltaRequest#writeExternal(java.io.ObjectOutput)
     *
     * @return serialized delta request
     *
     * @throws IOException IO error serializing
     */
    protected byte[] serialize() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        writeExternal(oos);
        oos.flush();
        oos.close();
        return bos.toByteArray();
    }

    private static class AttributeInfo implements Externalizable {
        private String name = null;
        private Object value = null;
        private int action;
        private int type;

        AttributeInfo() {
            this(-1, -1, null, null);
        }

        AttributeInfo(int type, int action, String name, Object value) {
            super();
            init(type, action, name, value);
        }

        public void init(int type, int action, String name, Object value) {
            this.name = name;
            this.value = value;
            this.action = action;
            this.type = type;
        }

        public int getType() {
            return type;
        }

        public int getAction() {
            return action;
        }

        public Object getValue() {
            return value;
        }

        @Override
        public int hashCode() {
            return name.hashCode();
        }

        public String getName() {
            return name;
        }

        public void recycle() {
            name = null;
            value = null;
            type = -1;
            action = -1;
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof AttributeInfo)) {
                return false;
            }
            AttributeInfo other = (AttributeInfo) o;
            return other.getName().equals(this.getName());
        }

        @Override
        public void readExternal(java.io.ObjectInput in) throws IOException, ClassNotFoundException {
            // type - int
            // action - int
            // name - String
            // hasvalue - boolean
            // value - object
            type = in.readInt();
            action = in.readInt();
            name = in.readUTF();
            boolean hasValue = in.readBoolean();
            if (hasValue) {
                value = in.readObject();
            }
        }

        @Override
        public void writeExternal(java.io.ObjectOutput out) throws IOException {
            // type - int
            // action - int
            // name - String
            // hasvalue - boolean
            // value - object
            out.writeInt(getType());
            out.writeInt(getAction());
            out.writeUTF(getName());
            out.writeBoolean(getValue() != null);
            if (getValue() != null) {
                out.writeObject(getValue());
            }
        }

        @Override
        public String toString() {
            return "AttributeInfo[type=" + getType() + ", action=" + getAction() + ", name=" + getName() + ", value=" +
                    getValue() + ", addr=" + super.toString() + ']';
        }

    }

}
