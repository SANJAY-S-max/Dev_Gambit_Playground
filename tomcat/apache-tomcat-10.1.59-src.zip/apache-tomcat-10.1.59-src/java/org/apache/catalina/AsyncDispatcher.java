/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

/**
 * Interface for performing asynchronous dispatch operations within the container.
 */
public interface AsyncDispatcher {

    /**
     * Perform an asynchronous dispatch. The method does not check if the request is in an appropriate state for this;
     * it is the caller's responsibility to check this.
     *
     * @param request  The request object to pass to the dispatch target
     * @param response The response object to pass to the dispatch target
     *
     * @throws ServletException if thrown by the dispatch target
     * @throws IOException      if an I/O error occurs while processing the dispatch
     */
    void dispatch(ServletRequest request, ServletResponse response) throws ServletException, IOException;
}
