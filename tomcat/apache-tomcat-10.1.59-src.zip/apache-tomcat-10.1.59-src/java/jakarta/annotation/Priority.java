/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jakarta.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Used to define the order in which classes or parameters should be used. The annotated class or parameter defines how
 * the prority value is used.
 *
 * @since Common Annotations 1.2
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Priority {

    /**
     * Specifies the priority value used to determine the ordering of the annotated
     * element. Lower values indicate higher priority. The annotated class or
     * parameter defines how the priority value is interpreted and applied.
     *
     * @return the priority ordering value
     */
    int value();
}
