/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jakarta.transaction;

/**
 * Thrown when an operation is attempted on a transaction that has been rolled back.
 */
public class TransactionRolledbackException extends java.rmi.RemoteException {

    private static final long serialVersionUID = -3142798139623020577L;

    /**
     * Constructs a {@code TransactionRolledbackException} with no detail message.
     */
    public TransactionRolledbackException() {
        super();
    }

    /**
     * Constructs a {@code TransactionRolledbackException} with the specified detail message.
     *
     * @param msg the detail message
     */
    public TransactionRolledbackException(String msg) {
        super(msg);
    }
}
