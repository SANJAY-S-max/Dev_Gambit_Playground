/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jakarta.websocket;

/**
 * Represents the result of an asynchronous WebSocket message send operation.
 */
public final class SendResult {
    private final Throwable exception;
    private final boolean ok;

    public SendResult(Throwable exception) {
        this.exception = exception;
        this.ok = (exception == null);
    }

    public SendResult() {
        this(null);
    }

    /**
     * Returns the exception that occurred during the send operation, or {@code null} if the
     * operation was successful.
     *
     * @return The exception, or {@code null} if successful
     */
    public Throwable getException() {
        return exception;
    }

    /**
     * Returns whether the send operation was successful.
     *
     * @return {@code true} if the send was successful, {@code false} otherwise
     */
    public boolean isOK() {
        return ok;
    }
}
