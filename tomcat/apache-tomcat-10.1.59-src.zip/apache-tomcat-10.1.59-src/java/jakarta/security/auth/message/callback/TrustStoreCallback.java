/**
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package jakarta.security.auth.message.callback;

import java.security.KeyStore;

import javax.security.auth.callback.Callback;

/**
 * A Callback enabling an authentication module to request a truststore from the runtime.
 */
public class TrustStoreCallback implements Callback {

    private KeyStore trustStore;

    /**
     * Constructs a new TrustStoreCallback.
     */
    public TrustStoreCallback() {
    }

    /**
     * Sets the trust store to be used for certificate validation.
     *
     * @param trustStore The trust store containing trusted certificates
     */
    public void setTrustStore(KeyStore trustStore) {
        this.trustStore = trustStore;
    }

    /**
     * Returns the trust store.
     *
     * @return The trust store, or {@code null} if not set
     */
    public KeyStore getTrustStore() {
        return trustStore;
    }
}
